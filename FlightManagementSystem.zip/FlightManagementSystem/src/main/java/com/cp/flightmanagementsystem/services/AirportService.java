package com.cp.flightmanagementsystem.services;

import java.util.*;

public class AirportService {
	
	
	      public List viewAirport(List<Airport>  ) {
	    	  
	    	    return 
	      }
	      public String viewAirport(String ) {
	    	  
	    	      
	    	  return 
	      }

}
