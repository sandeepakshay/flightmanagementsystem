package com.cp.flightmanagementsystem.services;

import com.cp.flightmanagementsystem.dto.Airport;
import com.cp.flightmanagementsystem.dto.ScheduledFlight;

import java.util.List;

import com.cp.flightmanagementsystem.dao.*;

public class ScheduledFlightService {
	
	
	          ScheduledFlightServiceDao sc=new ScheduledFlightServiceDao();
	          
	         //Schedules a flight along with its timings, locations and capacity
	
	         public void  scheduleFlight(ScheduledFlight s) {
	        	 
	        	 if(sc.scheduleFlightDao(s)) {
	        		 
	        		  System.out.println("scheduled  added");
	        	 }
	        	    	 
	        	 
	         }
	         
	         public List<ScheduledFlight> viewScheduledFlights(String flightname) { 
	        	 
	        	   return sc.viewScheduledFlightsDao(flightname);
	        	   
	         }
	         
}       
	         
	         
	         //Returns a list of flights between two airports on a specified date.
	         
/*	         public List<ScheduledFlight> viewScheduledFlights(Airport , Airport ,LocalDate ) {
	        	 
	        	 
	        	 
	        	  return 
	         }
	         
	       //Returns a list of a scheduled flight identifiable by flight number.
	         
	         public Flight viewScheduledFlights(String) { 
	        	 
	        	   
	        	   return 
	         }
	         
	       //Shows all the details and status of all flights.
	         
	         public List<ScheduledFlight> viewScheduleFlight(){  
	        	 
	        	 
	        	  return 
	         }
	         
	        // Modifies the details of a scheduled flight.
	         
	         public void modifyScheduledFlight(Flight  ,Schedule  ,integer) {
	        	 
	        	 
	        	 
	         }
	         
	         //Removes a flight from the available flights.
	         
	         public void deleteScheduledFlight(String ) {
	        	 
	        	 
	        	 
	         }
	         
	         //Validates the attributes of a scheduled Flight.
	         
	         public void validateScheduledFlight(ScheduledFlight ) {
	        	 
	        	 
	        	 
	        	 
	         }
	         

}*/
