package com.cp.flightmanagementsystem.util;

import java.util.ArrayList;

import com.cp.flightmanagementsystem.dto.Airport;

import com.cp.flightmanagementsystem.dto.*;

public class ScheduledFlightRepository {

	
	public ArrayList<ScheduledFlight> scheduledFlightArray=new ArrayList<ScheduledFlight>();
    
    public ArrayList<ScheduledFlight> getAirportArray() {
    	
        return scheduledFlightArray;
    }

    public void setAirportArray(ArrayList<ScheduledFlight> scheduledFlight) {
       
    	this.scheduledFlightArray=scheduledFlight;
    	
    }

}
