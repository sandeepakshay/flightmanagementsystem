package com.cp.flightmanagementsystem.dto;

public class ScheduledFlight {

	        
	          String flight;
	          int availableSeats;
	          Schedule schedule;
	          
	           public ScheduledFlight(String flight,int availableSeats,Schedule schedule){
	        	   
	        	      this.flight=flight;
	        	      this.availableSeats=availableSeats;
	        	      this.schedule=schedule;
	        	   
	           }
	           public String getFlight() {
	        	   
	        	   return flight;
	           }
	           public int getAvailableSeats() {
	        	   
	        	   return availableSeats;
	           }
	           public Schedule getSchedule() {
	        	   
	        	     return schedule;
	           }
	
	       
}
