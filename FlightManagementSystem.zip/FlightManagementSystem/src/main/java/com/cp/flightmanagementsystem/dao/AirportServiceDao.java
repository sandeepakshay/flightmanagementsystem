package com.cp.flightmanagementsystem.dao;

import java.util.List;

import com.cp.flightmanagementsystem.util.*;

import com.cp.flightmanagementsystem.dto.*;

import java.util.*;

public class AirportServiceDao {

	AirportRepository airportRepository=new AirportRepository();
	
	
	
	 public ArrayList<Airport> viewAirportDao() {
   	  
 	      return airportRepository.getAirportArray();  
      }
     
     
}
