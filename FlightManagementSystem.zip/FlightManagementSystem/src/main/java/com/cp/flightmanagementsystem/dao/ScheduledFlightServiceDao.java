package com.cp.flightmanagementsystem.dao;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.cp.flightmanagementsystem.dao.*;
import com.cp.flightmanagementsystem.dto.*;
import com.cp.flightmanagementsystem.services.*;
import com.cp.flightmanagementsystem.util.*;

public class ScheduledFlightServiceDao {

	
	ScheduledFlightRepository scheduleFlightRepo=new ScheduledFlightRepository();
	
	      //Schedules a flight along with its timings, locations and code.
	
       public boolean  scheduleFlightDao(ScheduledFlight s ) {
    	   
    	   
    	    boolean check= scheduleFlightRepo.scheduledFlightArray.add(s);
    	     
    	     return check;
       }
       
       public List<ScheduledFlight> viewScheduledFlightsDao(String flightname) { 
    	   	 
      	    
    	      List<ScheduledFlight> flightList=new ArrayList<ScheduledFlight>();
    	      
    	      for(ScheduledFlight element:scheduleFlightRepo.scheduledFlightArray) {
    	      
    	      if(flightname==element.getFlight()) {
    	    	  
    	    	    flightList.add(element);
    	      }
    	          	  
    	      }
    	      return flightList; 
        }
}       



        
    
       //Returns a list of flights between two airports on a specified date.
    
/*   public List<ScheduledFlight> viewScheduledFlightsDao(Airport a1, Airport a2 ,LocalDate date) {
   	 
    	   for()
   	 
   	      return 
      }
     
      //Returns a list of a scheduled flight identifiable by flight number.
    
      public List<ScheduledFlight> viewScheduledFlightsDao(String) { 
   	 
   	    
   	      return 
       }
    
      //Shows all the details and status of all flights.
    
      public List<ScheduledFlight> viewScheduleFlightDao(){  
   	 
   	 
   	  
    	  return 
      }
    
       // Modifies the details of a scheduled flight.
    
      public void modifyScheduledFlightDao(Flight  ,Schedule  ,int ) {
   	 
   	 
   	 
      }
    
      //Removes a flight from the available flights.
    
      public void deleteScheduledFlightDao(String ) {
   	 
   	 
   	 
      }
    
}*/
