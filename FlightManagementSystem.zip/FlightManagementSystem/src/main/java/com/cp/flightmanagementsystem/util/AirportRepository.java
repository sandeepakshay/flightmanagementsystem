package com.cp.flightmanagementsystem.util;

import com.cp.flightmanagementsystem.dto.*;

import java.util.*;

public class AirportRepository {
	
	
	
	        ArrayList<Airport> airportData=new ArrayList<Airport>();
	        
	        
	        
	        public ArrayList<Airport> getAirportArray() {
	        	
	            return airportData;
	        }

	        public void setAirportArray(ArrayList<Airport> airportData) {
	           
	        	this.airportData=airportData;
	        	
	        }

}
