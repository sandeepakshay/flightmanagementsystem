package com.cp.flightmanagementsystem.ui;

import java.text.ParseException;
import java.util.List;

import com.cp.flightmanagementsystem.dto.Airport;
import com.cp.flightmanagementsystem.dto.Schedule;
import com.cp.flightmanagementsystem.dto.ScheduledFlight;
import com.cp.flightmanagementsystem.services.ScheduledFlightService;
import com.cp.flightmanagementsystem.util.ScheduledFlightRepository;

public class Client {

	public static void main(String[] args) throws ParseException {
		
		
		ScheduledFlightRepository result=new ScheduledFlightRepository(); 
		
		ScheduledFlightService sc2=new ScheduledFlightService();
		
	
		
		 sc2.scheduleFlight(new ScheduledFlight("6E4929",300,new Schedule(new Airport("vizag",null,null),new Airport("delhi",null,null))));
		 sc2.scheduleFlight(new ScheduledFlight("6E2254",350,new Schedule(new Airport("hyd",null,null),new Airport("vizag",null,null))));
		 
		 List<ScheduledFlight> flightResult=sc2.viewScheduledFlights("6E2254");
		 
		 for(ScheduledFlight output:flightResult) {
			 
			 System.out.println(output.getFlight());
			 System.out.println(output.getAvailableSeats());
			 System.out.println(output.getSchedule().getSourceAirport().getAirportName());
			 System.out.println(output.getSchedule().getDestinationAirport().getAirportName());
			 
		 }
		       
		 
	}

}
